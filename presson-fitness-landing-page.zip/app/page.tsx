const formAction = 'https://formspree.io/f/your-form-id'

function Field({ label, name, type = 'text', required = true }: { label: string; name: string; type?: string; required?: boolean }) {
  return (
    <label className="field">
      <span>{label}</span>
      <input name={name} type={type} required={required} />
    </label>
  )
}

function SectionHeading({ eyebrow, title, copy }: { eyebrow: string; title: string; copy: string }) {
  return (
    <div className="section-heading">
      <p className="eyebrow">{eyebrow}</p>
      <h2>{title}</h2>
      <p>{copy}</p>
    </div>
  )
}

export default function Page() {
  return (
    <main>
      <header className="site-header">
        <a className="brand" href="#top" aria-label="Presson Fitness Gym home">
          <img className="logo-image" src="/images/presson-logo.png" alt="Presson Fitness Gym logo" />
          <span>PRESSON<span>FITNESS GYM</span></span>
        </a>
        <nav aria-label="Primary navigation">
          <a href="/about">About us</a>
          <a href="/services">Services</a>
          <a href="/gallery">Gallery</a>
          <a href="/contact">Contact us</a>
          <a className="nav-cta" href="#join">Join now</a>
        </nav>
      </header>

      <section className="hero" id="top">
        <div className="hero-copy">
          <p className="eyebrow">Presson Fitness Gym</p>
          <h1>Train harder.<br /><em>Live stronger.</em></h1>
          <p className="hero-intro">Build your goals with the right energy, refreshing drinks, and a supportive community.</p>
          <a className="button button-gold" href="#join">Join now <span>→</span></a>
        </div>
        <div className="hero-art" aria-label="Athlete training at Presson Fitness Gym">
          <div className="sun-disc" />
          <div className="hero-word">PRESS<br /><span>ON</span></div>
          <div className="art-caption">01 / TRAIN WITH PURPOSE</div>
          <div className="art-line" />
        </div>
      </section>

      <section className="ticker" aria-label="Gym values">
        <span>DISCIPLINE</span><b>+</b><span>POWER</span><b>+</b><span>PROGRESS</span><b>+</b><span>COMMUNITY</span>
      </section>

      <section className="intro-section container" id="about">
        <SectionHeading eyebrow="01 — The Presson standard" title="Built for the work." copy="No shortcuts. No distractions. Just a better place to train, with expert coaching and the energy to keep you moving." />
        <div className="principles">
          <article><span>01</span><h3>Show up</h3><p>Consistency beats intensity. We help you make training part of your life.</p></article>
          <article><span>02</span><h3>Push further</h3><p>Progress starts where comfort ends. Find your next level with us.</p></article>
          <article><span>03</span><h3>Stay ready</h3><p>Train, fuel, recover, repeat. Everything you need under one roof.</p></article>
        </div>
      </section>

      <section className="dark-band" id="products">
        <div className="container split-section">
          <SectionHeading eyebrow="02 — What we offer" title="Fuel your session." copy="Stay sharp between sets with our hand-picked range of energy drinks, cold water, and fresh coffee." />
          <div className="product-grid">
            <div className="product-card"><span className="product-icon">✦</span><h3>Energy</h3><p>More energy, more you.</p></div>
            <div className="product-card"><span className="product-icon">◯</span><h3>Hydration</h3><p>Stay ready. Stay sharp.</p></div>
            <div className="product-card"><span className="product-icon">⌁</span><h3>Coffee</h3><p>Fuel your day.</p></div>
          </div>
        </div>
      </section>

      <section className="container form-section" id="join">
        <div className="form-intro"><SectionHeading eyebrow="03 — Start your membership" title="Make your move." copy="Tell us a little about yourself and we will get you set up for your first session." /></div>
        <form className="styled-form" action={formAction} method="POST">
          <input type="hidden" name="form_type" value="membership_registration" />
          <Field label="Full name" name="name" />
          <Field label="Phone number" name="phone" type="tel" />
          <label className="field"><span>Membership tier</span><select name="membership" required><option value="">Choose a plan</option><option>1-Month</option><option>3-Month</option><option>Annual</option></select></label>
          <button className="button button-dark" type="submit">Join now <span>↗</span></button>
        </form>
      </section>

      <section className="service-section" id="services">
        <div className="container booking-layout">
          <div><SectionHeading eyebrow="04 — Services & coaching" title="Book your next session." copy="Whether you are new to training or chasing a new personal best, our coaches are here to help." /><div className="service-list"><span>01 / Personal training</span><span>02 / Group strength</span><span>03 / Open gym access</span></div></div>
          <form className="styled-form dark-form" action={formAction} method="POST"><input type="hidden" name="form_type" value="online_booking" /><Field label="Full name" name="name" /><Field label="Phone number" name="phone" type="tel" /><div className="two-fields"><Field label="Preferred date" name="date" type="date" /><Field label="Preferred time" name="time" type="time" /></div><button className="button button-gold" type="submit">Book online <span>↗</span></button></form>
        </div>
      </section>

      <section className="gallery-section container" id="gallery"><div className="gallery-title"><SectionHeading eyebrow="05 — The space" title="Come as you are. Leave stronger." copy="A space designed for the work. Scroll through our training floor, gear, and community." /></div><div className="gallery-grid"><div className="gallery-tile tile-one"><span>TRAIN</span></div><div className="gallery-tile tile-two"><span>RECOVER</span></div><div className="gallery-tile tile-three"><span>REPEAT</span></div></div></section>

      <section className="contact-section" id="contact"><div className="container contact-layout"><div><SectionHeading eyebrow="06 — Contact us" title="Let’s get to work." copy="Questions, group bookings, or just want to say hey? Drop us a note." /><p className="contact-detail">123 Fitness Avenue, Quezon City, Philippines<br />pressongym@gmail.com<br />+63 912 345 6789<br />Mon — Sun · 6:00 AM — 11:00 PM</p></div><form className="styled-form" action={formAction} method="POST"><input type="hidden" name="form_type" value="contact_inquiry" /><Field label="Full name" name="name" /><Field label="Email address" name="email" type="email" /><label className="field"><span>Message</span><textarea name="message" rows={4} required /></label><button className="button button-gold" type="submit">Send inquiry <span>↗</span></button></form></div></section>

      <footer className="site-footer"><div className="container footer-inner"><a className="brand" href="#top"><img className="logo-image" src="/images/presson-logo.png" alt="Presson Fitness Gym logo" /><span>PRESSON<span>FITNESS GYM</span></span></a><p>© 2026 Presson Fitness Gym. Train harder. Live stronger.</p><a href="#top">Back to top ↑</a></div></footer>
    </main>
  )
}
